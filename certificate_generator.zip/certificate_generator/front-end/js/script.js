document.addEventListener("DOMContentLoaded", () => {

    const tableBody = document.getElementById('tableBody');
    const downloadCsvButton = document.getElementById('downloadCsv');

    toggleDownloadButton();

    tableBody.addEventListener('DOMSubtreeModified', toggleDownloadButton);

    let socket = io("http://localhost:3000"); // Connect to bot
    socket.on("connect", () => {
        sendNotification("success", "Connected to bot.");
        loadingScreen(false);
    })

    socket.on("disconnect", () => {
        loadingScreen(true)
    })

    async function sendNotification(type, message) {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-right',
            customClass: {
                popup: 'colored-toast'
            },
            showConfirmButton: false,
            timer: 3500,
            timerProgressBar: true
        })

        await Toast.fire({
            icon: type == "success" ? "success" : "error",
            title: message
        })
    }

    function loadingScreen(boolean) {
        document.querySelector('.loadingScreen').style.display = boolean ? "flex" : "none";
        document.querySelector('.section').style.display = !boolean ? "block" : "none";
    }


    document.querySelector(".file-input").addEventListener("change", (event) => {
        const fileList = event.target.files;
        const reader = new FileReader();

        reader.onload = function (event) {
            const fileContent = event.target.result;
            const rows = fileContent.split('\n').map(row => row.replace(/,/g, ':'));
            for(const row of rows) {
                document.querySelector(".input").value += row + "\n"
            }
        };

        reader.readAsText(fileList[0]);
    }, false);

    document.querySelector("#start").addEventListener("click", () => {
        let data = [];
        let lines = document.querySelector(".input").value.split("\n")
        for(let i = 0; i < lines.length; i++) {
            data.push(lines[i].split(":"))
        }
        // Here i have to write some logic to check if the data is valid or not
        sendNotification("success", "Certificate sent to student's email!")
        socket.emit("start-bot", [data])
    })

    document.querySelector("#stop").addEventListener("click", () => {
        sendNotification("success", "Stop request has been made!")
        socket.emit("stop-bot")
    })

    socket.on("data-updated", (updatedData) => {
        const tableBody = document.getElementById("tableBody");
        tableBody.innerHTML = ""; // Clear the existing table rows
        // console.log(updatedData)
        updatedData.forEach(rowData => {
          addRowToTable(rowData);
        });
      });

    function addRowToTable(rowData) {
        const tableBody = document.getElementById("tableBody");
        const newRow = document.createElement("tr");
        rowData.forEach(data => {
          const cell = document.createElement("td");
          cell.textContent = data;
          newRow.appendChild(cell);
        });
        tableBody.appendChild(newRow);
    }

    // Function to enable or disable the button based on the table body content
    function toggleDownloadButton() {
    if (tableBody.innerHTML.trim() !== '') {
        downloadCsvButton.removeAttribute('disabled');
    } else {
        downloadCsvButton.setAttribute('disabled', 'disabled');
    }
    }

    // Function to extract the data from the table
    function extractTableData() {
        const rows = tableBody.querySelectorAll('tr');
    
        // const filteredRows = Array.from(rows).filter((row) => {
        // const statusCell = row.querySelector('td:last-child');
        // return statusCell.textContent.trim() === 'Not sent';
        // });
    
        const csvContent = Array.from(rows)
        .map((row) => {
            const cells = Array.from(row.querySelectorAll('td'));
            // Remove the last cell (Status column)
            // cells.pop();
            return cells.map((cell) => cell.textContent.trim()).join(',');
        })
        .join('\n');
    
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    
        // Create a temporary anchor element to trigger the download
        const downloadLink = document.createElement('a');
        downloadLink.href = URL.createObjectURL(blob);
        downloadLink.download = 'certificate_data.csv';
    
        // Trigger the download
        downloadLink.click();
    }
  
    downloadCsvButton.addEventListener('click', extractTableData);

})