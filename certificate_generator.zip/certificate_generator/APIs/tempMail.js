const axios = require('axios');
const cheerio = require('cheerio');
const https = require('https');
const fs = require('fs');
const config = require('../Certificates/config');
const { file } = require('googleapis/build/src/apis/file');

// Function to generate a temporary email address .
async function generateTempEmail() {
  try {
    const response = await axios.get('https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1');
    const email = response.data[0];
    return email;
  } catch (error) {
    console.error(error);
  }
}
function generatePassword() {
  const letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const numbers = '0123456789';
  const characters = `${letters}${numbers}!@#$%^&*()_+-=[]{}|;:,.<>?`;
  const passwordLength = Math.floor(Math.random() * 5) + 8; // Generate random length between 8 and 12
  let password = '';

  // Generate random letters
  for (let i = 0; i < 4; i++) {
      const randomIndex = Math.floor(Math.random() * letters.length);
      const randomChar = letters.charAt(randomIndex);
      password += randomChar;
  }

  // Generate random numbers
  for (let i = 0; i < 4; i++) {
      const randomIndex = Math.floor(Math.random() * numbers.length);
      const randomChar = numbers.charAt(randomIndex);
      password += randomChar;
  }

  // Build password string with unique characters
  while (password.length < passwordLength) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      const randomChar = characters.charAt(randomIndex);

      if (!password.includes(randomChar)) {
          password += randomChar;
      }
  }

  return password;
}
// Function to check inbox for received emails
async function checkTempEmailInbox(email, firstName, secondName) {
  let tries = 12;
  while (tries > 0) {
    try {
      const response = await axios.get(`https://www.1secmail.com/api/v1/?action=getMessages&login=${email.split('@')[0]}&domain=${email.split('@')[1]}`);
      const messages = response.data;

      // Loop through all email messages
      for (const message of messages) {
        const messageId = message.id;
        const messageResponse = await axios.get(`https://www.1secmail.com/api/v1/?action=readMessage&login=${email.split('@')[0]}&domain=${email.split('@')[1]}&id=${messageId}`);
        const subject = messageResponse.data.subject;
        const body = messageResponse.data.body;

        // Check if email subject starts with "Download your completion certificate"
        if (subject.startsWith("Download your completion certificate")) {
          tries = 0
          const getLink = await extractLinkFromHtml(body)
          const getNewLink = await axios.get(getLink)
          await downloadPdf(getNewLink.request.res.responseUrl, `${firstName} ${secondName}.pdf`, config.BRITISH_AIRWAYS.OUTPUT_FILE_PATH)
          return getLink
        }
      }
      console.log("No messages found..")
      tries--;
      await sleep(3500)
    } catch (error) {
      console.error(error);
    }
  }

  function extractLinkFromHtml(html) {
    return new Promise((resolve, reject) => {
      const $ = cheerio.load(html);
      const link = $('a').attr('href');
      if (link) {
        resolve(link);
      } else {
        reject('No link found in HTML');
      }
    });
  }
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function downloadPdf(url, fileName, path) {
  console.log(url, fileName)
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(path + fileName);
    https.get(url, function (response) {
      response.pipe(file);
      file.on('finish', function () {
        file.close();
        console.log('File download complete');
        resolve()
      });
    }).on('error', function (error) {
      fs.unlink(fileName);
      console.error('Error downloading file:', error);
      reject()
    });
  })
}
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
module.exports = { generateTempEmail, generatePassword,checkTempEmailInbox, downloadPdf , sleep}