const fs = require('fs');
// const fl = require('fs')
const path = require('path');
const process = require('process');
// const { authenticate } = require('@google-cloud/local-auth');
// const { google } = require('googleapis');
// const token = require('./token.json')
// const config = require("../Certificates/config")
// let auth;

// // If modifying these scopes, delete token.json.
// const SCOPES = ['https://www.googleapis.com/auth/gmail.send', 'https://www.googleapis.com/auth/gmail.compose'];
// const TOKEN_PATH = './token.json';
// const CREDENTIALS_PATH = path.join(__dirname, 'privatekey.json');

// async function loadSavedCredentialsIfExist() {
//     try {
//         const content = await fs.readFile(TOKEN_PATH);
//         const credentials = JSON.parse(content);
//         return google.auth.fromJSON(credentials);
//     } catch (err) {
//         return null;
//     }
// }

// async function saveCredentials(client) {
//     const content = await fs.readFile(CREDENTIALS_PATH);
//     const keys = JSON.parse(content);
//     const key = keys.installed || keys.web;
//     const payload = JSON.stringify({
//         type: 'authorized_user',
//         client_id: key.client_id,
//         client_secret: key.client_secret,
//         refresh_token: client.credentials.refresh_token,
//     });
//     await fs.writeFile(TOKEN_PATH, payload);
// }

// async function authorize() {
//     let client = await loadSavedCredentialsIfExist();
//     if (client) {
//         auth = client
//         return client;
//     }
//     client = await authenticate({
//         scopes: SCOPES,
//         keyfilePath: CREDENTIALS_PATH,
//     });
//     if (client.credentials) {
//         await saveCredentials(client);
//     }
//     auth = client
//     return client;
// } authorize()

// async function sendEmail(to, certificateName, filePath) {
//     const gmail = google.gmail({ version: 'v1', auth });
//     const fileContent = fl.readFileSync(filePath);
//     const encodedFile = Buffer.from(fileContent).toString('base64');

//     const message = [
//         'Content-Type: multipart/mixed; boundary="boundary-example"',
//         'MIME-Version: 1.0',
//         'From: ' + token.from,
//         'To: ' + to,
//         'Subject: Claim your certificate ' + certificateName,
//         '',
//         '--boundary-example',
//         'Content-Type: text/html; charset=utf-8',
//         '',
//         'Hello,',
//         '',
//         `I have attached your certificate for ${certificateName} down below, thanks!`,
//         '',
//         '--boundary-example',
//         'Content-Type: application/pdf; name="' + path.basename(filePath) + '"',
//         'Content-Disposition: attachment; filename="' + path.basename(filePath) + '"',
//         'Content-Transfer-Encoding: base64',
//         '',
//         encodedFile,
//         '',
//         '--boundary-example--',
//     ].join('\n');

//     const encodedMessage = Buffer.from(message)
//         .toString('base64')
//         .replace(/\+/g, '-')
//         .replace(/\//g, '_')
//         .replace(/=+$/, '');

//     const res = await gmail.users.messages.send({
//         userId: 'me',
//         requestBody: {
//             raw: encodedMessage,
//         },
//     });
// }
const aws = require('aws-sdk');
const emailTemplate = require('./emailTemplate');
const ses = new aws.SES({
  signatureVersion: "v4",
  region: "ap-south-1",
  accessKeyId: "AKIAQXQIQAXX44IFRK6V",
  secretAccessKey: "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",
});

  function createRawEmail(recipient, sender, subject, bodyText, attachmentData) {
    const boundary = `aws-multipart-boundary-${Date.now()}`;
    const header = `From: ${sender}\nTo: ${recipient}\nSubject: ${subject}\nMIME-Version: 1.0\nContent-Type: multipart/mixed; boundary="${boundary}"\n\n`;
    const body = `--${boundary}\nContent-Type: text/html; charset="UTF-8"\n\n${bodyText}\n\n`;
    const attachment = `--${boundary}\nContent-Type: application/pdf\nContent-Disposition: attachment; filename="Certificate.pdf"\nContent-Transfer-Encoding: base64\n\n${attachmentData.toString('base64')}\n\n`;
    const footer = `--${boundary}--`;
  
    return header + body + attachment + footer;
  }
  

async function sendEmail(to, certificateName, filePath) {
    const attachmentData = fs.readFileSync(filePath);

    const params = {
        Source: 'mnc@devtown.in',
        RawMessage: {
          Data: createRawEmail(to, 'mnc@devtown.in', 'Claim your certificate ' + certificateName, emailTemplate(certificateName), attachmentData)
        }
      };
    
      // Send the email
      ses.sendRawEmail(params, (err, data) => {
        if (err) {
          console.log('Error sending email:', err);
        } else {
          console.log('Email sent successfully:', data);
        }
      });
}

module.exports = sendEmail;
