const http = require("http");
const socketio = require("socket.io");
//use function name same as these names
const British_Airways = require("./British_Airways/main");
const Accenture = require("./Accenture/main"); 
const Lyft = require("./Lyft/main");
const ANZ = require("./ANZ/main");
const AIG = require("./AIG/main");
const Deloitte = require("./Deloitte/main");
const HPE = require("./HPE/main");
const Goldman = require("./Goldman/main");
const AWS = require("./AWS/main");
const TATA = require("./TATA/main");
const BCG = require("./BCG/main");
const JPMC = require("./JPMC/main");
const BCG_VENTURES = require("./BCG_Ventures/main"); // not working
const BCG_DESIGN = require("./BCG_DESIGN/main");
const BP = require("./BP/main");
const MBRC = require("./MBRC/main");
const Pwc_Cybersecurity = require("./Pwc_Cybersecurity/main");
const Common_Wealth = require("./Common_Wealth/main");
const MasterCard = require("./MasterCard/main");
const Telstra_Cybersecurity = require("./Telstra_Cybersecurity/main");
const Telstra_Software = require("./Telstra_Software/main");
const GWC = require("./GWC/main");
const Pwc_PowerBI = require("./Pwc_PowerBI/main");
const Lyft_MobileEngg = require("./Lyft_MobileEngg/main");
const Spectris = require("./Spectris/main");
const Skyscanner_Software = require("./Skyscanner_Software/main");
const Skyscanner_Frontend = require("./Skyscanner_Frontend/main");
const EWB = require("./EWB/main");
const DataCom = require("./DataCom/main");
const H2Ventures = require("./H2Ventures/main");
const Quantium_DataScience = require("./Quantium_DataScience/main");
const KPMG_Technology = require("./KPMG_Technology/main");
const SAP = require("./SAP/main");
const StandardBank_Dev = require("./StandardBank_Dev/main");
const StandardBank_Engg = require("./StandardBank_Engg/main");
const BlackBird = require("./BlackBird/main");
const Walmart_USA = require("./Walmart_USA/main");
const Y_Combinator = require("./Y_Combinator/main");
const Cognizant = require("./Cognizant/main");
const Cognizant_USA = require("./Cognizant_USA/main");
const Electronic_Arts = require("./Electronic_Arts/main");
const JPmorgan_SoftwareLite = require("./JPmorgan_SoftwareLite/main");
const JPmorgan_CyberSecurity = require("./JPmorgan_Cybersecurity/main");
const GE = require("./GE/main");
const Quantium_Software = require("./Quantium_Software/main");
const Accenture_Data = require("./Accenture_Data/main");

const sendEmail = require("../APIs/sendMail");

const server = http.createServer();
const io = socketio(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});
let status = "Not started";
io.on("connection", (socket) => {
  console.log("A user connected");

  socket.on("disconnect", () => {
    console.log("A user disconnected");
  });

  socket.on("start-bot", async (dat) => {
    const updatedData = []; // Array to store the updated data
    console.log(dat);
    for (let i = 0; i < dat[0].length; i++) {
      const data = dat[0][i];
      const args = `("${data[0]}", "${data[1]}", "${data[2]}")`;
      console.log(args, "I am from args args");
      const status = await eval(data[3] + args);
      const updatedRow = [...data, status]; // Add the status to the row data
      updatedData.push(updatedRow); // Store the updated row in the array
      socket.emit("data-updated", updatedData); // Emit the updated data to the frontend
    }
  });
  socket.on("stop-bot", () => {
    console.log("Bot stopped");
  });
});

server.listen(3000, () => {
  console.log("Server running on port 3000");
});
