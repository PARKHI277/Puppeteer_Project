// For file paths, right click on folders/files and paste the full path here.
// The first word of the variable is the name of the file/folder
const path = require("path");
const base = __dirname;
// const api_base = "G:/internship/shapeAI-phase-2/Certificate_Generator/Certificate_Generator/Certificate_Generator/APIs";
const api_base = path.join(__dirname, "../APIs");
// "G:/internship/shapeAI-phase-2/Certificate_Generator/Certificate_Generator/Certificate_Generator/APIs";
const config = {
  HEADLESS: false,
  OUTPUT_FILE_PATH: base + "/British_Airways/output/",
  // OUTPUT_FILE_PATH: "C:/Users/shaur/Downloads/Certificate_Generator/Certificate_Generator/Certificates/British_Airways/output/",
  MAIL_FILE_PATH: base + "/British_Airways/output/",
  // MAIL_FILE_PATH: "C:\\Users\\shaur\\Downloads\\Certificate_Generator\\Certificate_Generator\\Certificates\\British_Airways\\output\\",
  TOKEN_FILE_PATH: api_base + "/token.json",
  // TOKEN_FILE_PATH: 'C:/Users/shaur/Downloads/Certificate_Generator/Certificate_Generator/APIs/token.json',
  PRIVATEKEY_FILE_PATH: api_base + "/privatekey.json",
  // PRIVATEKEY_FILE_PATH: ':/Users/shaur/Downloads/Certificate_Generator/Certificate_Generator/APIs/privatekey.json',

  BRITISH_AIRWAYS: {
    OUTPUT_FILE_PATH: base + "/British_Airways/output/",

    TASK1_FILE_PATH: base + "/British_Airways/Task1.pptx",
    TASK2_FILE_PATH: base + "/British_Airways/Task2.pptx",
    // TASK1_FILE_PATH: "C:/Users/shaur/Downloads/Certificate_Generator/Certificate_Generator/Certificates/British_Airways/Task1.pptx",
    // TASK2_FILE_PATH: "C:/Users/shaur/Downloads/Certificate_Generator/Certificate_Generator/Certificates/British_Airways/Task2.pptx"
  },
  Accenture: {
    OUTPUT_FILE_PATH: base + "/Accenture/output/",
    TASK1_FILE_PATH: base + "/Accenture/Task1.fig",
  },
  Walmart_USA: {
    OUTPUT_FILE_PATH: base + "/Walmart/output/",
    TASK1_FILE_PATH: base + "/Walmart/Task1.docx",
    TASK2_FILE_PATH: base + "/Walmart/Task2.pdf",
    TASK3_FILE_PATH: base + "/Walmart/Task4.docx",
    TASK4_FILE_PATH: base + "/Walmart/Task4.docx",
  },
  Lyft: {
    OUTPUT_FILE_PATH: base + "/Lyft/output/",
    TASK1_FILE_PATH: base + "/Lyft/Task1.pdf",
  },
  KPMG_Technology: {
    OUTPUT_FILE_PATH: base + "/KPMG_Technology/output/",
  },
  ANZ: {
    OUTPUT_FILE_PATH: base + "/ANZ/output/",
    TASK1_FILE_PATH: base + "/ANZ/Task1.pdf",
    TASK2_FILE_PATH: base + "/ANZ/Task2.docx",
  },
  AIG: {
    OUTPUT_FILE_PATH: base + "/AIG/output/",
  },
  Deloitte: {
    OUTPUT_FILE_PATH: base + "/Deloitte/output/",
    TASK2_FILE_PATH: base + "/Deloitte/Task1.pdf",
  },
  HPE: {
    OUTPUT_FILE_PATH: base + "/HPE/output/",
    TASK1_FILE_PATH: base + "/HPE/Task1.pdf",
    TASK3_FILE_PATH: base + "/HPE/Task3.zip",
  },
  Goldman: {
    OUTPUT_FILE_PATH: base + "/Goldman/output/",
  },
  AWS: {
    OUTPUT_FILE_PATH: base + "/AWS/output",
  },
  Infosys: {
    OUTPUT_FILE_PATH: base + "/Infosys/output/",

    TASK1_FILE_PATH: base + "/Infosys/Task1.zip",
    TASK2_FILE_PATH: base + "/Infosys/Task2.patch",
  },
  TATA: {
    OUTPUT_FILE_PATH: base + "/TATA/output/",
    TASK1_FILE_PATH: base + "/TATA/Task.pbix",
    TASK2_FILE_PATH: base + "/Accenture/Task4.mp4",
    TASK4_FILE_PATH: base + "/TATA/Task4.webm",
  },
  BCG: {
    OUTPUT_FILE_PATH: base + "/BCG/output/",
    TASK1_FILE_PATH: base + "/BCG/Task1.pdf",
    TASK2_FILE_PATH: base + "/BCG/Task2.pptx",
  },
  JPMC: {
    OUTPUT_FILE_PATH: base + "/JPMC/output/",
    TASK1_FILE_PATH: base + "/JPMC/Task1.patch",
    TASK2_FILE_PATH: base + "/JPMC/Task2.pptx",
  },
  BCG_VENTURES: {
    OUTPUT_FILE_PATH: base + "/BCG_Ventures/output/",
    TASK2_FILE_PATH: base + "/BCG_Ventures/Task2.pptx",
  },
  BCG_DESIGN: {
    OUTPUT_FILE_PATH: base + "/BCG_DESIGN/output/",
  },
  BP: {
    OUTPUT_FILE_PATH: base + "/BP/output/",
    TASK1_FILE_PATH: base + "/BP/Task1.pdf",
  },
  MBRC: {
    OUTPUT_FILE_PATH: base + "/MBRC/output/",
    TASK1_FILE_PATH: base + "/MBRC/Task1.pdf",
    TASK2_FILE_PATH: base + "/MBRC/Task2.zip",
  },
  Pwc_Cybersecurity: {
    OUTPUT_FILE_PATH: base + "/Pwc_Cybersecurity/output/",
    TASK1_FILE_PATH: base + "/Pwc_Cybersecurity/Task1.pptx",
    TASK2_FILE_PATH: base + "/Pwc_Cybersecurity/Task2.mp3",
    TASK3_FILE_PATH: base + "/Pwc_Cybersecurity/Task3.pdf",
    TASK4_FILE_PATH: base + "/Pwc_Cybersecurity/Task3.pdf",
  },
  Common_Wealth: {
    OUTPUT_FILE_PATH: base + "/Common_Wealth/output/",
    TASK1_FILE_PATH: base + "/Common_Wealth/Task1.json",
    TASK2_FILE_PATH: base + "/Common_Wealth/Task2.tsx",
    TASK3_FILE_PATH: base + "/Common_Wealth/Task3.ts",
    TASK4_FILE_PATH: base + "/Common_Wealth/Task4.txt",
    TASK5_FILE_PATH: base + "/Common_Wealth/Task5.txt",
  },
  MasterCard: {
    OUTPUT_FILE_PATH: base + "/MasterCard/output/",
  },
  Telstra_Cybersecurity: {
    OUTPUT_FILE_PATH: base + "/Telstra_Cybersecurity/output/",
    TASK1_FILE_PATH: base + "/Telstra_Cybersecurity/Task1.docx",
    TASK2_FILE_PATH: base + "/Telstra_Cybersecurity/Task2.docx",
    TASK3_FILE_PATH: base + "/Telstra_Cybersecurity/Task3.py",
    TASK4_FILE_PATH: base + "/Telstra_Cybersecurity/Task4.docx",
  },
  Telstra_Software: {
    OUTPUT_FILE_PATH: base + "/Telstra_Cybersecurity/output/",
  },
  GWC: {
    OUTPUT_FILE_PATH: base + "/GWC/output/",
    TASK1_FILE_PATH: base + "/GWC/Task1.pdf",
    TASK2_FILE_PATH: base + "/GWC/Task4.webm",
  },
  Pwc_PowerBI: {
    OUTPUT_FILE_PATH: base + "/Pwc_PowerBI/output/",
    TASK1_FILE_PATH: base + "/Pwc_PowerBI/Task3.pdf",
  },
  Lyft_MobileEngg: {
    OUTPUT_FILE_PATH: base + "/Lyft_MobileEngg/output/",
    TASK2_FILE_PATH: base + "/Lyft_MobileEngg/Task2.zip",
  },
  Spectris: {
    OUTPUT_FILE_PATH: base + "/Spectris/output/",
    TASK1_FILE_PATH: base + "/Spectris/Task1.pdf",
  },
  Skyscanner_Software: {
    OUTPUT_FILE_PATH: base + "/Skyscanner_Software/output/",
    TASK4_FILE_PATH: base + "/Skyscanner_Software/Task4.docx",
  },
  Skyscanner_Frontend: {
    OUTPUT_FILE_PATH: base + "/Skyscanner_Frontend/output/",
  },
  EWB: {
    OUTPUT_FILE_PATH: base + "/EWB/output/",
    TASK2_FILE_PATH: base + "/EWB/Task2.pdf",
    TASK3_FILE_PATH: base + "/EWB/Task3.pptx",
    TASK4_FILE_PATH: base + "/EWB/Task4.docx",
  },
  DataCom: {
    OUTPUT_FILE_PATH: base + "/DataCom/output/",
    TASK2_FILE_PATH: base + "/DataCom/Task2.zip",
  },
  H2Ventures: {
    OUTPUT_FILE_PATH: base + "/H2Ventures/output/",
    TASK1_FILE_PATH: base + "/H2Ventures/Task1.pdf",
    TASK3_FILE_PATH: base + "/H2Ventures/Task3.xlsx",
    TASK2_FILE_PATH: base + "/H2Ventures/Task2.pdf",
  },
  Quantium_DataScience: {
    OUTPUT_FILE_PATH: base + "/Quantium_DataScience/output/",
    TASK1_FILE_PATH: base + "/Quantium_DataScience/Task1.pdf",
    TASK2_FILE_PATH: base + "/Quantium_DataScience/Task2.pptx",
    TASK3_FILE_PATH: base + "/Quantium_DataScience/Task3.docx",
  },
  SAP: {
    OUTPUT_FILE_PATH: base + "/SAP/output/",
    TASK1_FILE_PATH: base + "/SAP/Task1.docx",
    TASK3_FILE_PATH: base + "/SAP/Task4.webm",
  },
  StandardBank_Dev: {
    OUTPUT_FILE_PATH: base + "/StandardBank_Dev/output/",
  },
  StandardBank_Engg: {
    OUTPUT_FILE_PATH: base + "/StandardBank_Engg/output/",
    TASK3_FILE_PATH: base + "/StandardBank_Engg/Task3.csv",
  },
  BlackBird: {
    OUTPUT_FILE_PATH: base + "/BlackBird/output/",
  },
  Walmart_USA: {
    OUTPUT_FILE_PATH: base + "/Walmart_USA/output/",
    TASK1_FILE_PATH: base + "/Walmart_USA/Task1.csv",
    TASK2_FILE_PATH: base + "/Walmart_USA/Task2.pdf",
  },
  Y_Combinator: {
    OUTPUT_FILE_PATH: base + "/Y_Combinator/output/",
    TASK1_FILE_PATH: base + "/Y_Combinator/task1.sql",
    TASK2_FILE_PATH: base + "/Y_Combinator/task2.patch",
  },
  Cognizant: {
    OUTPUT_FILE_PATH: base + "/Cognizant/output/",
    TASK2_FILE_PATH: base + "/Cognizant/Task2.pdf",
    TASK4_FILE_PATH: base + "/Cognizant/Task4.csv",
  },
  Cognizant_USA: {
    OUTPUT_FILE_PATH: base + "/Cognizant_USA/output/",
  },
  Electronic_Arts: {
    OUTPUT_FILE_PATH: base + "/Electronic_Arts/output/",
  },
  JPmorgan_SoftwareLite: {
    OUTPUT_FILE_PATH: base + "/JPmorgan_SoftwareLite/output/",
  },
  JPmorgan_CyberSecurity: {
    OUTPUT_FILE_PATH: base + "/JPmorgan_CyberSecurity/output/",
  },
  JPMorgan_Software: {
    OUTPUT_FILE_PATH: base + "/JPMorgan_Software/output/",
  },
  GE: {
    OUTPUT_FILE_PATH: base + "/GE/output/",
  },
  Quantium_Software: {
    OUTPUT_FILE_PATH: base + "/Quantium_Software/output/",
  },
  Accenture_Data: {
    OUTPUT_FILE_PATH: base + "/Accenture_Data/output/",
  },
};

module.exports = config;
