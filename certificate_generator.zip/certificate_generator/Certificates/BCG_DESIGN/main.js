const { chromium } = require("playwright");
const stealth = require("puppeteer-extra-plugin-stealth")();
// chromium.use(stealth)
const {
  generateTempEmail,
  checkTempEmailInbox,
  downloadPdf,
  generatePassword,
  sleep,
} = require("../../APIs/tempMail");
const sendEmail = require("../../APIs/sendMail");
const config = require("../config.js");

async function main(studentEmail, firstName, secondName) {
  try {
    const randomEmail = await generateTempEmail();
    const randomPassword = generatePassword();
    console.log(`Registering using: ${randomEmail}:${randomPassword}`);
    const browser = await chromium.launch({
      headless: config.HEADLESS,
      args: ["--start-fullscreen"],
    });
    const context = await browser.newContext({
      plugins: [stealth],
    });
    const page = await context.newPage();
    page.setDefaultTimeout(0);
    // Go to website
    await page.goto("https://www.theforage.com/");
    // Signup starts
    await page.getByRole("link", { name: "Sign up" }).click();
    await page.getByRole("button", { name: "Sign up with Email" }).click();
    await page.getByLabel("First Name *").click();
    await page.getByLabel("First Name *").fill(firstName);
    await page.getByLabel("First Name *").press("Tab");
    await page.getByLabel("Last Name *").fill(secondName);
    await page.getByLabel("Last Name *").press("Tab");
    await page.getByLabel("Email *").fill(randomEmail);
    await page.getByLabel("Email *").press("Tab");
    await page
      .getByLabel("Password (Minimum 8 Characters) *")
      .fill(randomPassword);
    await page
      .locator("label")
      .filter({ hasText: "In High School" })
      .locator("svg")
      .first()
      .click();
    await page
      .getByRole("button", { name: "Please select a high school" })
      .click();
    await page.getByText("Lebanon High SchoolUS - Lebanon").click();
    await page.getByRole("button", { name: "Select an option" }).click();
    await page.locator("a").filter({ hasText: "Google Search" }).click();
    await page.getByRole("button", { name: "Register" }).click();
    await page
      .locator("label")
      .filter({
        hasText:
          "By ticking this box, your parent/legal guardian has agreed to you participating in our job simulations. If your parent/legal guardian does not agree, then you may explore our job simulations",
      })
      .locator("span")
      .click();
    await page.getByRole("button", { name: "Register" }).click();
    console.log(`${firstName} has registered on theforage.com`);
    // Signup ends
    await page.getByRole("button", { name: "Skip" }).click();
    await page.getByRole("button", { name: "Skip" }).click();
    await page.getByRole("button", { name: "Skip" }).click();
    await page.getByRole("button", { name: "Skip" }).click();
    await page.getByRole("button", { name: "Skip" }).click();
    await page.getByRole("button", { name: "Skip" }).click();
    await page.getByRole("button", { name: "Skip" }).click();
    await page.getByRole("button", { name: "Skip" }).click();
    await page.getByRole("button", { name: "Get started" }).click();
    await page.goto(
      "https://www.theforage.com/virtual-internships/prototype/WkzSp3gqQriGfpM7H/BCG-Design?ref=SxPv5zCR38naCsijd"
    );

    // await clickButtonByRoleWithTimeout(page, "button", "Register Now", 10000);
    await clickButtonByRoleWithTimeout(
      page,
      "button",
      "Start Free Program",
      10000
    );
    await sleep(10000);

    await page.getByText("Instagram").click();
    await page.getByText("Google").click();
    await page.getByRole("button", { name: "Next" }).click();
    await page
      .getByText("I want to build my design skills to help my career")
      .click();
    await page.getByRole("button", { name: "Next" }).click();
    await page.getByRole("button", { name: "Strongly Agree" }).click();
    await page.getByRole("button", { name: "Strongly Agree" }).click();
    await page.getByRole("button", { name: "Strongly Agree" }).click();
    await page.getByRole("button", { name: "Yes" }).click();
    await page.getByText("I Agree").click();
    await page.getByText("I Agree").click();

    await sleep(10000);
    while (
      (await page
        .getByRole("button", {
          name: "Go to the Virtual Experience Program now →",
        })
        .count()) > 0
    ) {
      console.log("this line is executed for a temporary page");
      await page
        .getByRole("button", {
          name: "Go to the Virtual Experience Program now →",
        })
        .first()
        .click();
    }

    // Task 1
    await page.getByText("Next").click();
    await sleep(3000);
    await page.getByLabel("Next").click();
    await sleep(3000);
    var fileChooserPromise = page.waitForEvent("filechooser");
    await page.getByText("Select a File").click();
    var fileChooser = await fileChooserPromise;
    await fileChooser.setFiles(config.Walmart_USA.TASK2_FILE_PATH);
    await sleep(2000);
    await page.getByRole("button", { name: "Submit" }).click();
    await sleep(3000);
    await page.locator("#footer").getByLabel("Next").click();
    await sleep(3000);
    await page.getByLabel("Complete").click();
    await sleep(3000);
    await page.getByText("Skip and Go To Next Task").click();

    //task2
    await sleep(3000);
    await page.getByText("Next").click();
    await sleep(3000);
    await page.getByLabel("Next").click();
    await sleep(3000);
    var fileChooserPromise = page.waitForEvent("filechooser");
    await page.getByText("Select a File").click();
    var fileChooser = await fileChooserPromise;
    await fileChooser.setFiles(config.Walmart_USA.TASK2_FILE_PATH);
    await sleep(2000);
    await page.getByRole("button", { name: "Submit" }).click();
    await sleep(3000);
    await page.locator("#footer").getByLabel("Next").click();
    await sleep(3000);
    await page.getByLabel("Complete").click();
    await sleep(3000);
    await page.getByText("Skip and Go To Next Task").click();

    //task3
    await sleep(3000);
    await page.getByText("Next").click();
    await sleep(3000);
    await page.getByLabel("Next").click();
    await sleep(3000);
    var fileChooserPromise = page.waitForEvent("filechooser");
    await page.getByText("Select a File").click();
    var fileChooser = await fileChooserPromise;
    await fileChooser.setFiles(config.Walmart_USA.TASK2_FILE_PATH);
    await sleep(2000);
    await page.getByRole("button", { name: "Submit" }).click();
    await sleep(3000);
    await page.locator("#footer").getByLabel("Next").click();
    await sleep(3000);
    await page.getByLabel("Complete").click();
    await sleep(3000);
    await page.getByText("Skip and Go To Next Task").click();
    //task4
    await sleep(3000);
    await page.getByText("Next").click();
    await sleep(3000);
    await page.getByLabel("Next").click();
    await sleep(3000);
    var fileChooserPromise = page.waitForEvent("filechooser");
    await page.getByText("Select a File").click();
    var fileChooser = await fileChooserPromise;
    await fileChooser.setFiles(config.Walmart_USA.TASK2_FILE_PATH);
    await sleep(2000);
    await page.getByRole("button", { name: "Submit" }).click();
    await sleep(3000);
    await page.locator("#footer").getByLabel("Next").click();
    await sleep(3000);
    await page.getByLabel("Complete").click();
    await sleep(3000);
    await page.getByText("Skip and Go To Next Task").click();

    // task5
    await page.getByLabel("Next").click();
    await sleep(3000);
    await page.getByText("Start your quiz").click();
    await page
      .getByText(
        "A research plan defines the objectives of the research and how to conduct a research activity by detailing out the protocol before starting."
      )
      .click();

    await page.getByLabel("Next").click();

    await page.getByText("Purpose, Interview Guides, Methods").click();
    await page.getByLabel("Next").click();
    await sleep(1000);
    await page
      .getByText(
        "A hypothetical representation of needs, desires, pain points and behaviours of people who share common traits."
      )
      .click();
    await page.getByLabel("Next").click();
    await sleep(1000);
    await page.getByText("All of the above").click();
    await page.getByLabel("Next").click();
    await sleep(1000);
    await page.getByText("True").click();
    await page.getByLabel("Next").click();
    await sleep(1000);
    await page.getByText("All of the above").click();
    await page.getByLabel("Next").click();
    await sleep(1000);
    await page.getByText("False").click();
    await page.getByLabel("Next").click();
    await sleep(1000);
    await page.getByText("All of the above").click();

    await page.getByLabel("Complete").click();
    await sleep(3000);
    await page.getByText("Start Next Task").click();

    await sleep(3000);
    await page.getByText("Next").click();

    //download certificate

    await page.getByText("Get My Certificate").click();
    await page.getByText("Strongly Agree").click();
    await page.getByText("Next").click();
    await page.getByText("Strongly Agree").click();
    await page.getByText("Next").click();
    await page.getByText("Strongly Agree").click();
    await page.getByText("Next").click();
    await page.getByText("Strongly Agree").click();
    await page.getByText("Next").click();
    await page
      .getByText(
        "I confirm that I have reviewed and consented to the BCG CV Policy"
      )
      .click();
    await page.getByText("Next").click();

    const labelSelector =
      "label.___ref-label.mantine-Rating-label.mantine-vqoiw6";
    await page.evaluate((selector) => {
      const labelElement = document.querySelector(selector);
      if (labelElement) {
        labelElement.click();
      } else {
        console.log("Label element not found");
      }
    }, labelSelector);
    await page.getByText("Next").click();
    await page.getByText("Next").click();

    await page.getByText(`Yes, I'd love to!`).click();
    await page.getByText("Submit").click();
    await page.getByRole("button", { name: "Certificate" }).click();
    // await page.getByRole("button", { name: "Accept All Cookies" }).click();
    await page.getByText("Accept All Cookies").click();

    // await page.getByText("Certificate").click();
    const [newPage] = await Promise.all([
      context.waitForEvent("page"),
      page.getByText("Accept All Cookies").click(),
      // await page.getByRole("button", { name: "Download" }).click(),
      page.locator("a").filter({ hasText: "Download" }).click(),
    ]);

    const newPageUrl = await newPage.url();
    console.log(
      "\x1b[36m%s\x1b[0m",
      `Generated certificate for ${firstName} ${secondName}`
    );
    downloadPdf(
      newPageUrl,
      `${firstName} ${secondName}.pdf`,
      config.BCG_DESIGN.OUTPUT_FILE_PATH
    );
    // await checkTempEmailInbox(randomEmail, firstName, secondName)
    await sleep(10000);
    await sendEmail(
      studentEmail,
      "BCG Design",
      `${config.BCG_DESIGN.OUTPUT_FILE_PATH}${firstName} ${secondName}.pdf`
    );
    await browser.close();
    // Generic methods
    async function clickButtonByRoleWithTimeout(page, role, name, timeoutMs) {
      const timeoutPromise = new Promise((resolve, reject) => {
        setTimeout(() => {
          reject(new Error(`Timed out after ${timeoutMs}ms`));
        }, timeoutMs);
      });

      const buttonPromise = page.getByRole(role, { name });

      try {
        await Promise.race([buttonPromise, timeoutPromise]);
        const button = await buttonPromise;
        await button.first().click();
        return button;
      } catch (error) {
        console.error(error.message);
        // handle timeout error
        throw error;
      }
    }

    return "Sent";
  } catch (e) {
    console.log(e);
    return "Not sent";
  }
}

module.exports = main;
